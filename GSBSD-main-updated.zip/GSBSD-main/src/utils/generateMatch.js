export function generateMatch(players, matchHistory, options = {}) {
  const {
    allowSpecialPatterns = false,
    allowMixedGender = false,
    partyAB = false,
  } = options;

  // Only players marked Active are eligible
  const activePlayers = players.filter(
    (p) => p.Active === true || p.Active === "TRUE"
  );

  // Nothing to do if fewer than 4 active players
  if (activePlayers.length < 4) return null;

  // Last match players (for back-to-back avoidance)
  const lastMatchPlayers = (() => {
    if (!matchHistory || matchHistory.length === 0) return [];
    const lastMatch = matchHistory[matchHistory.length - 1];
    return Array.isArray(lastMatch) ? lastMatch : [];
  })();

  const isBackToBack = (teamPlayers) =>
    teamPlayers.some((p) => lastMatchPlayers.includes(p.Name));

  const gradeStrength = (grade) => {
    switch (grade) {
      case "S":
        return 4;
      case "A":
        return 3;
      case "B":
        return 2;
      case "C":
        return 1;
      default:
        return 0;
    }
  };

  const gamesPlayed = (p) => {
    const gp = p?.["Games Played"];
    const n = typeof gp === "string" ? parseInt(gp, 10) : gp;
    return Number.isFinite(n) ? n : 0;
  };

  // Helper: compare grade multisets between teams (e.g. S+S vs S+S, A+B vs A+B)
  const sameGradePattern = (team1, team2) => {
    const a = team1.map((p) => p.Grade).sort().join(",");
    const b = team2.map((p) => p.Grade).sort().join(",");
    return a === b;
  };

  // Generate all unique 4-player combinations split into 2v2
  const combos = [];

  for (let i = 0; i < activePlayers.length; i++) {
    for (let j = i + 1; j < activePlayers.length; j++) {
      for (let k = 0; k < activePlayers.length; k++) {
        for (let l = k + 1; l < activePlayers.length; l++) {
          const team1 = [activePlayers[i], activePlayers[j]];
          const team2 = [activePlayers[k], activePlayers[l]];

          // Must be 4 unique players
          const names = new Set([
            team1[0].Name,
            team1[1].Name,
            team2[0].Name,
            team2[1].Name,
          ]);
          if (names.size !== 4) continue;

          // Mixed gender rule: each team must be 1M + 1F
          if (allowMixedGender) {
            const t1M = team1.filter((p) => p.Gender === "M").length;
            const t1F = team1.filter((p) => p.Gender === "F").length;
            const t2M = team2.filter((p) => p.Gender === "M").length;
            const t2F = team2.filter((p) => p.Gender === "F").length;
            if (!(t1M === 1 && t1F === 1 && t2M === 1 && t2F === 1)) continue;
          }

          // Party AB rule: A+B vs A+B
          if (partyAB) {
            const t1 = team1.map((p) => p.Grade).sort().join(",");
            const t2 = team2.map((p) => p.Grade).sort().join(",");
            if (!(t1 === "A,B" && t2 === "A,B")) continue;
          }

          // Special patterns: mirror team grade composition (e.g. S+S vs S+S, A+B vs A+B, etc.)
          if (allowSpecialPatterns && !sameGradePattern(team1, team2)) continue;

          const team = [...team1, ...team2];

          // Score combo for fairness & balance
          const totalGames = team.reduce((sum, p) => sum + gamesPlayed(p), 0);
          const maxGames = Math.max(...team.map(gamesPlayed));
          const minGames = Math.min(...team.map(gamesPlayed));
          const gamesSpread = maxGames - minGames; // smaller is fairer

          const strength1 = team1.reduce((sum, p) => sum + gradeStrength(p.Grade), 0);
          const strength2 = team2.reduce((sum, p) => sum + gradeStrength(p.Grade), 0);
          const strengthDiff = Math.abs(strength1 - strength2); // smaller is more balanced

          const b2b = isBackToBack(team) ? 1 : 0;

          // Weighted score: avoid B2B first, then minimize games spread / overuse, then balance teams
          // (Lower score is better)
          const score =
            b2b * 1_000_000 +
            gamesSpread * 10_000 +
            totalGames * 100 +
            strengthDiff * 10 +
            Math.random(); // tiny random to avoid always same outcome

          combos.push({ team, team1, team2, score, b2b });
        }
      }
    }
  }

  if (combos.length === 0) return null;

  // Pick best-scoring combo
  combos.sort((a, b) => a.score - b.score);
  const best = combos[0];

  if (best.b2b) {
    console.log("⚠️ No non-back-to-back matches available. Using best available fallback.");
  }

  return best.team;
}
